import React from 'react';

const Counter = ({ count, onDecrement, onIncrement, onReset, onChangeCount, click, }) => {

    return (
      <div>

        <div>
          <button onClick={onDecrement}>-</button>
          <span>{count}</span>
          <button onClick={onIncrement}>+</button>
          <br />
          {/* <button onClick={onReset}>Reset</button> */}
        </div>

        <div>
        <label>Times the increment/decrement buttons have been clicked: {click}</label>
        <br />
        <input id="input" type="number"/>
        <button onClick={onChangeCount}>Change Count Number</button>

        </div>

      </div>
    );
}


export default Counter;