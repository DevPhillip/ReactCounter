const initialState = {
  count: 0,
  click: 0,
  addAmount: 0
};

function counterReducer(state = initialState, action) {
  switch (action.type) {
    case 'INCREMENT':
      return {
        ...state,
        count: state.count + 1,
        click: state.click + 1
      };
    case 'DECREMENT':
      return {
        ...state,
        count: state.count - 1,
        click: state.click + 1
      };
    // case 'RESET':
    //   return {
    //     ...state,
    //     count: (state.count = 0)
    //   };
    case 'CHANGE':
      return {
        ...state,
        addAmount: state.addAmount = parseInt(document.getElementById('input').value),
        count: state.addAmount,
        click: 0
      };
    default:
      return state;
  }
}

export default counterReducer;